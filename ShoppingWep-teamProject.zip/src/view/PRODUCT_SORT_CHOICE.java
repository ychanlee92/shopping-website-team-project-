package view;

public interface PRODUCT_SORT_CHOICE {
	public static final int MINPRICE = 1;
	public static final int MAXPRICE = 2;
	public static final int CATEGORY = 3;
	public static final int BRAND = 4;
	public static final int BACK = 5;
}
