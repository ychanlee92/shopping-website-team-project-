package view;

public interface START_CHOICE {
	public static final int SIGNIN = 1;
	public static final int SIGNUP = 2;
	public static final int EXIT = 3;
}
