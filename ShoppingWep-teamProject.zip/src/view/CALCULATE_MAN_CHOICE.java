package view;

public interface CALCULATE_MAN_CHOICE {
	public static final int DATE_LIST = 1;
	public static final int PRODUCT_LIST = 2;
	public static final int BACK = 3;
}
