package view;

public interface CUSTOMER_MAIN_CHOICE {
	public static final int MYPAGE = 1;
	public static final int PRODUCT= 2;
	public static final int CART = 3;
	public static final int PAYMENT = 4;
	public static final int EXIT = 5;
}
