package view;

public interface ADMIN_MAIN_CHOICE {
	public static final int USER_MAN = 1;
	public static final int PRODUCT_MAN = 2;
	public static final int CALCULATE_MAN = 3;
	public static final int EXIT = 4;
}
