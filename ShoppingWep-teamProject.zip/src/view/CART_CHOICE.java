package view;

public interface CART_CHOICE {
	public static final int LIST =1;
	public static final int DELETE_ITEM =2;
	public static final int DELETE_CART =3;
	public static final int BACK =4;
}
