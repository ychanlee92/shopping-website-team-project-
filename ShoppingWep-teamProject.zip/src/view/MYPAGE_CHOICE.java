package view;

public interface MYPAGE_CHOICE {
	public static final int SHOWINFO = 1;
	public static final int UPDATE = 2;
	public static final int DELETEACCOUNT = 3;
	public static final int PAYMENT_LIST = 4;
	public static final int BACK = 5;
}
