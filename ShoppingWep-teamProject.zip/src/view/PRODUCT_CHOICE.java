package view;

public interface PRODUCT_CHOICE {
	public static final int LIST =1;
	public static final int SEARCH =2;
	public static final int ADDITEM =3;
	public static final int BACK =4;
}
