package view;

public interface PRODUCT_MAN_CHOICE {
	public static final int LIST = 1;
	public static final int INSERT = 2;
	public static final int UPDATE = 3;
	public static final int DELETE = 4;
	public static final int BACK = 5;
}
