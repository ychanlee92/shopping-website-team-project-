package view;

public interface USER_MAN_CHOICE {
	public static final int LIST = 1;
	public static final int UPDATE = 2;
	public static final int DELETE = 3;
	public static final int BACK = 4;
}
